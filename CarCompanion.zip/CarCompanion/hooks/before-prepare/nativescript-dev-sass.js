module.exports = require("nativescript-dev-sass/lib/before-prepare.js");
