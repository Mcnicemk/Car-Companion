import { NgModule } from "@angular/core";
import { Routes } from "@angular/router";
import { NativeScriptRouterModule } from "nativescript-angular/router";

const routes: Routes = [
    { path: "", redirectTo: "/home", pathMatch: "full" },
    { path: "home", loadChildren: "./home/home.module#HomeModule" },
    { path: "fuel", loadChildren: "./fuel/fuel.module#FuelModule" },
    { path: "service", loadChildren: "./service/service.module#ServiceModule" },
    { path: "trips", loadChildren: "./trips/trips.module#TripsModule" },
    { path: "settings", loadChildren: "./settings/settings.module#SettingsModule" },
    { path: "register", loadChildren: "./register/register.module#RegisterModule" }
];

@NgModule({
    imports: [NativeScriptRouterModule.forRoot(routes)],
    exports: [NativeScriptRouterModule]
})
export class AppRoutingModule { }
