"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var observable_1 = require("tns-core-modules/data/observable");
var nativescript_directions_1 = require("nativescript-directions");
var HelloWorldModel = (function (_super) {
    __extends(HelloWorldModel, _super);
    function HelloWorldModel() {
        var _this = _super.call(this) || this;
        _this.directions = new nativescript_directions_1.Directions();
        return _this;
    }
    HelloWorldModel.prototype.doCheckAvailable = function () {
        this.directions.available().then(function (avail) {
            console.log("Avail? " + avail);
            alert(avail);
        }, function (err) {
            alert(err);
        });
    };
    HelloWorldModel.prototype.doCurrentLocationToAddress = function () {
        this.directions.navigate({
            to: {
                address: "Hof der Kolommen 34, Amersfoort, Netherlands"
            }
        }).then(function () {
            console.log("Current location to address directions launched!");
        }, function (err) {
            alert(err);
        });
    };
    HelloWorldModel.prototype.doAddressToAddressToAddress = function () {
        this.directions.navigate({
            from: {
                address: "Hof der Kolommen 34, Amersfoort, Netherlands"
            },
            to: [
                {
                    address: "Middenstraat 21, Loppersum, Netherlands"
                },
                {
                    address: "Aak 98, Wieringerwerf, Netherlands"
                }
            ],
            ios: {
                allowGoogleMapsWeb: true
            }
        }).then(function () {
            console.log("Address to address directions launched!");
        }, function (err) {
            alert(err);
        });
    };
    HelloWorldModel.prototype.doAddressToCoordinate = function () {
        this.directions.navigate({
            from: {
                address: "Hof der Kolommen 34, Amersfoort, Netherlands"
            },
            to: [{
                    lat: 52.215987,
                    lng: 5.282764
                }],
            ios: {
                preferGoogleMaps: false
            }
        }).then(function () {
            console.log("Address to coord directions launched!");
        }, function (err) {
            alert(err);
        });
    };
    HelloWorldModel.prototype.doCoordinateToCoordinate = function () {
        this.directions.navigate({
            from: {
                lat: 52.215987,
                lng: 5.282764
            },
            to: {
                lat: 52.515987,
                lng: 5.382764
            }
        }).then(function () {
            console.log("Coord to coord directions launched!");
        }, function (err) {
            alert(err);
        });
    };
    return HelloWorldModel;
}(observable_1.Observable));
exports.HelloWorldModel = HelloWorldModel;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi12aWV3LW1vZGVsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibWFpbi12aWV3LW1vZGVsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsK0RBQThEO0FBQzlELG1FQUFxRDtBQUVyRDtJQUFxQyxtQ0FBVTtJQUc3QztRQUFBLFlBQ0UsaUJBQU8sU0FFUjtRQURDLEtBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxvQ0FBVSxFQUFFLENBQUM7O0lBQ3JDLENBQUM7SUFFTSwwQ0FBZ0IsR0FBdkI7UUFDRSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFDLEtBQUs7WUFDckMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLENBQUM7WUFDL0IsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2YsQ0FBQyxFQUFFLFVBQUMsR0FBRztZQUNMLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNiLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLG9EQUEwQixHQUFqQztRQUNFLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ3ZCLEVBQUUsRUFBRTtnQkFDRixPQUFPLEVBQUUsOENBQThDO2FBQ3hEO1NBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0RBQWtELENBQUMsQ0FBQztRQUNsRSxDQUFDLEVBQUUsVUFBQyxHQUFHO1lBQ0wsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0scURBQTJCLEdBQWxDO1FBQ0UsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7WUFDdkIsSUFBSSxFQUFFO2dCQUNKLE9BQU8sRUFBRSw4Q0FBOEM7YUFDeEQ7WUFDRCxFQUFFLEVBQUU7Z0JBQ0Y7b0JBQ0UsT0FBTyxFQUFFLHlDQUF5QztpQkFDbkQ7Z0JBQ0Q7b0JBQ0UsT0FBTyxFQUFFLG9DQUFvQztpQkFDOUM7YUFBQztZQUNKLEdBQUcsRUFBRTtnQkFDSCxrQkFBa0IsRUFBRSxJQUFJO2FBQ3pCO1NBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMseUNBQXlDLENBQUMsQ0FBQztRQUN6RCxDQUFDLEVBQUUsVUFBQyxHQUFHO1lBQ0wsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sK0NBQXFCLEdBQTVCO1FBQ0UsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7WUFDdkIsSUFBSSxFQUFFO2dCQUNKLE9BQU8sRUFBRSw4Q0FBOEM7YUFDeEQ7WUFDRCxFQUFFLEVBQUUsQ0FBQztvQkFDSCxHQUFHLEVBQUUsU0FBUztvQkFDZCxHQUFHLEVBQUUsUUFBUTtpQkFDZCxDQUFDO1lBQ0YsR0FBRyxFQUFFO2dCQUNILGdCQUFnQixFQUFFLEtBQUs7YUFDeEI7U0FDRixDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO1FBQ3ZELENBQUMsRUFBRSxVQUFDLEdBQUc7WUFDTCxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDYixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxrREFBd0IsR0FBL0I7UUFDRSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQztZQUN2QixJQUFJLEVBQUU7Z0JBQ0osR0FBRyxFQUFFLFNBQVM7Z0JBQ2QsR0FBRyxFQUFFLFFBQVE7YUFDZDtZQUNELEVBQUUsRUFBRTtnQkFDRixHQUFHLEVBQUUsU0FBUztnQkFDZCxHQUFHLEVBQUUsUUFBUTthQUNkO1NBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQXFDLENBQUMsQ0FBQztRQUNyRCxDQUFDLEVBQUUsVUFBQyxHQUFHO1lBQ0wsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBQ0gsc0JBQUM7QUFBRCxDQUFDLEFBdEZELENBQXFDLHVCQUFVLEdBc0Y5QztBQXRGWSwwQ0FBZSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9kYXRhL29ic2VydmFibGVcIjtcclxuaW1wb3J0IHsgRGlyZWN0aW9ucyB9IGZyb20gXCJuYXRpdmVzY3JpcHQtZGlyZWN0aW9uc1wiO1xyXG5cclxuZXhwb3J0IGNsYXNzIEhlbGxvV29ybGRNb2RlbCBleHRlbmRzIE9ic2VydmFibGUge1xyXG4gIHByaXZhdGUgZGlyZWN0aW9uczogRGlyZWN0aW9ucztcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgICBzdXBlcigpO1xyXG4gICAgdGhpcy5kaXJlY3Rpb25zID0gbmV3IERpcmVjdGlvbnMoKTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBkb0NoZWNrQXZhaWxhYmxlKCkge1xyXG4gICAgdGhpcy5kaXJlY3Rpb25zLmF2YWlsYWJsZSgpLnRoZW4oKGF2YWlsKSA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiQXZhaWw/IFwiICsgYXZhaWwpO1xyXG4gICAgICBhbGVydChhdmFpbCk7XHJcbiAgICB9LCAoZXJyKSA9PiB7XHJcbiAgICAgIGFsZXJ0KGVycik7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBkb0N1cnJlbnRMb2NhdGlvblRvQWRkcmVzcygpIHtcclxuICAgIHRoaXMuZGlyZWN0aW9ucy5uYXZpZ2F0ZSh7XHJcbiAgICAgIHRvOiB7XHJcbiAgICAgICAgYWRkcmVzczogXCJIb2YgZGVyIEtvbG9tbWVuIDM0LCBBbWVyc2Zvb3J0LCBOZXRoZXJsYW5kc1wiXHJcbiAgICAgIH1cclxuICAgIH0pLnRoZW4oKCkgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIkN1cnJlbnQgbG9jYXRpb24gdG8gYWRkcmVzcyBkaXJlY3Rpb25zIGxhdW5jaGVkIVwiKTtcclxuICAgIH0sIChlcnIpID0+IHtcclxuICAgICAgYWxlcnQoZXJyKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGRvQWRkcmVzc1RvQWRkcmVzc1RvQWRkcmVzcygpIHtcclxuICAgIHRoaXMuZGlyZWN0aW9ucy5uYXZpZ2F0ZSh7XHJcbiAgICAgIGZyb206IHtcclxuICAgICAgICBhZGRyZXNzOiBcIkhvZiBkZXIgS29sb21tZW4gMzQsIEFtZXJzZm9vcnQsIE5ldGhlcmxhbmRzXCJcclxuICAgICAgfSxcclxuICAgICAgdG86IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBhZGRyZXNzOiBcIk1pZGRlbnN0cmFhdCAyMSwgTG9wcGVyc3VtLCBOZXRoZXJsYW5kc1wiXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBhZGRyZXNzOiBcIkFhayA5OCwgV2llcmluZ2Vyd2VyZiwgTmV0aGVybGFuZHNcIlxyXG4gICAgICAgIH1dLFxyXG4gICAgICBpb3M6IHtcclxuICAgICAgICBhbGxvd0dvb2dsZU1hcHNXZWI6IHRydWVcclxuICAgICAgfVxyXG4gICAgfSkudGhlbigoKSA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiQWRkcmVzcyB0byBhZGRyZXNzIGRpcmVjdGlvbnMgbGF1bmNoZWQhXCIpO1xyXG4gICAgfSwgKGVycikgPT4ge1xyXG4gICAgICBhbGVydChlcnIpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgZG9BZGRyZXNzVG9Db29yZGluYXRlKCkge1xyXG4gICAgdGhpcy5kaXJlY3Rpb25zLm5hdmlnYXRlKHtcclxuICAgICAgZnJvbToge1xyXG4gICAgICAgIGFkZHJlc3M6IFwiSG9mIGRlciBLb2xvbW1lbiAzNCwgQW1lcnNmb29ydCwgTmV0aGVybGFuZHNcIlxyXG4gICAgICB9LFxyXG4gICAgICB0bzogW3tcclxuICAgICAgICBsYXQ6IDUyLjIxNTk4NyxcclxuICAgICAgICBsbmc6IDUuMjgyNzY0XHJcbiAgICAgIH1dLFxyXG4gICAgICBpb3M6IHtcclxuICAgICAgICBwcmVmZXJHb29nbGVNYXBzOiBmYWxzZVxyXG4gICAgICB9XHJcbiAgICB9KS50aGVuKCgpID0+IHtcclxuICAgICAgY29uc29sZS5sb2coXCJBZGRyZXNzIHRvIGNvb3JkIGRpcmVjdGlvbnMgbGF1bmNoZWQhXCIpO1xyXG4gICAgfSwgKGVycikgPT4ge1xyXG4gICAgICBhbGVydChlcnIpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgZG9Db29yZGluYXRlVG9Db29yZGluYXRlKCkge1xyXG4gICAgdGhpcy5kaXJlY3Rpb25zLm5hdmlnYXRlKHtcclxuICAgICAgZnJvbToge1xyXG4gICAgICAgIGxhdDogNTIuMjE1OTg3LFxyXG4gICAgICAgIGxuZzogNS4yODI3NjRcclxuICAgICAgfSxcclxuICAgICAgdG86IHtcclxuICAgICAgICBsYXQ6IDUyLjUxNTk4NyxcclxuICAgICAgICBsbmc6IDUuMzgyNzY0XHJcbiAgICAgIH1cclxuICAgIH0pLnRoZW4oKCkgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIkNvb3JkIHRvIGNvb3JkIGRpcmVjdGlvbnMgbGF1bmNoZWQhXCIpO1xyXG4gICAgfSwgKGVycikgPT4ge1xyXG4gICAgICBhbGVydChlcnIpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG59Il19