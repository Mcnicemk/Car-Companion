import { Component, OnInit, ViewChild,ElementRef, AfterViewInit } from "@angular/core";
import { DrawerTransitionBase, SlideInOnTopTransition } from "nativescript-pro-ui/sidedrawer";
import { RadSideDrawerComponent } from "nativescript-pro-ui/sidedrawer/angular";
import frameModule = require("tns-core-modules/ui/frame");
import { Directions } from "nativescript-directions";

import { RadialNeedle } from "nativescript-pro-ui/gauges";

@Component({
    selector: "Fuel",
    moduleId: module.id,
    templateUrl: "./fuel.component.html"
})
export class FuelComponent implements OnInit {
fstation="";

   private _needle: RadialNeedle;
    public values = [60, 80, 120, 160];

    //constructor() { }

    ngAfterViewInit() {
        this._needle = this.needleElement.nativeElement as RadialNeedle;
    }

    @ViewChild("needle") needleElement: ElementRef;

    public onValueChange(value: number) {
        this._needle.value = value;
    }

  constructor() {
    this.directions = new Directions();
  }
    private directions: Directions;
  doCurrentLocationToAddress() {
    this.directions.navigate({
      to: {
        address: this.fstation
      }
    }).then(() => {
      console.log("Current location to address directions launched!");
    }, (err) => {
      alert(err);
    });
  }
  consuption(){
  alert("ggg");
  }

    /* ***********************************************************
    * Use the @ViewChild decorator to get a reference to the drawer component.
    * It is used in the "onDrawerButtonTap" function below to manipulate the drawer.
    *************************************************************/
    @ViewChild("drawer") drawerComponent: RadSideDrawerComponent;

    private _sideDrawerTransition: DrawerTransitionBase;

    /* ***********************************************************
    * Use the sideDrawerTransition property to change the open/close animation of the drawer.
    *************************************************************/
    ngOnInit(): void {
        this._sideDrawerTransition = new SlideInOnTopTransition();
    }

    get sideDrawerTransition(): DrawerTransitionBase {
        return this._sideDrawerTransition;
    }

    /* ***********************************************************
    * According to guidelines, if you have a drawer on your page, you should always
    * have a button that opens it. Use the showDrawer() function to open the app drawer section.
    *************************************************************/
    onDrawerButtonTap(): void {
        this.drawerComponent.sideDrawer.showDrawer();
    }
}