"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var sidedrawer_1 = require("nativescript-pro-ui/sidedrawer");
var angular_1 = require("nativescript-pro-ui/sidedrawer/angular");
var nativescript_directions_1 = require("nativescript-directions");
var FuelComponent = (function () {
    function FuelComponent() {
        this.fstation = "";
        this.values = [60, 80, 120, 160];
        this.directions = new nativescript_directions_1.Directions();
    }
    //constructor() { }
    FuelComponent.prototype.ngAfterViewInit = function () {
        this._needle = this.needleElement.nativeElement;
    };
    FuelComponent.prototype.onValueChange = function (value) {
        this._needle.value = value;
    };
    FuelComponent.prototype.doCurrentLocationToAddress = function () {
        this.directions.navigate({
            to: {
                address: this.fstation
            }
        }).then(function () {
            console.log("Current location to address directions launched!");
        }, function (err) {
            alert(err);
        });
    };
    FuelComponent.prototype.consuption = function () {
        alert("ggg");
    };
    /* ***********************************************************
    * Use the sideDrawerTransition property to change the open/close animation of the drawer.
    *************************************************************/
    FuelComponent.prototype.ngOnInit = function () {
        this._sideDrawerTransition = new sidedrawer_1.SlideInOnTopTransition();
    };
    Object.defineProperty(FuelComponent.prototype, "sideDrawerTransition", {
        get: function () {
            return this._sideDrawerTransition;
        },
        enumerable: true,
        configurable: true
    });
    /* ***********************************************************
    * According to guidelines, if you have a drawer on your page, you should always
    * have a button that opens it. Use the showDrawer() function to open the app drawer section.
    *************************************************************/
    FuelComponent.prototype.onDrawerButtonTap = function () {
        this.drawerComponent.sideDrawer.showDrawer();
    };
    __decorate([
        core_1.ViewChild("needle"),
        __metadata("design:type", core_1.ElementRef)
    ], FuelComponent.prototype, "needleElement", void 0);
    __decorate([
        core_1.ViewChild("drawer"),
        __metadata("design:type", angular_1.RadSideDrawerComponent)
    ], FuelComponent.prototype, "drawerComponent", void 0);
    FuelComponent = __decorate([
        core_1.Component({
            selector: "Fuel",
            moduleId: module.id,
            templateUrl: "./fuel.component.html"
        }),
        __metadata("design:paramtypes", [])
    ], FuelComponent);
    return FuelComponent;
}());
exports.FuelComponent = FuelComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnVlbC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJmdWVsLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUF1RjtBQUN2Riw2REFBOEY7QUFDOUYsa0VBQWdGO0FBRWhGLG1FQUFxRDtBQVNyRDtJQWtCRTtRQWpCRixhQUFRLEdBQUMsRUFBRSxDQUFDO1FBR0QsV0FBTSxHQUFHLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFlbkMsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLG9DQUFVLEVBQUUsQ0FBQztJQUNyQyxDQUFDO0lBZEMsbUJBQW1CO0lBRW5CLHVDQUFlLEdBQWY7UUFDSSxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBNkIsQ0FBQztJQUNwRSxDQUFDO0lBSU0scUNBQWEsR0FBcEIsVUFBcUIsS0FBYTtRQUM5QixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7SUFDL0IsQ0FBQztJQU1ILGtEQUEwQixHQUExQjtRQUNFLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ3ZCLEVBQUUsRUFBRTtnQkFDRixPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVE7YUFDdkI7U0FDRixDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxrREFBa0QsQ0FBQyxDQUFDO1FBQ2xFLENBQUMsRUFBRSxVQUFDLEdBQUc7WUFDTCxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDYixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFDRCxrQ0FBVSxHQUFWO1FBQ0EsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2IsQ0FBQztJQVVDOztrRUFFOEQ7SUFDOUQsZ0NBQVEsR0FBUjtRQUNJLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLG1DQUFzQixFQUFFLENBQUM7SUFDOUQsQ0FBQztJQUVELHNCQUFJLCtDQUFvQjthQUF4QjtZQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUM7UUFDdEMsQ0FBQzs7O09BQUE7SUFFRDs7O2tFQUc4RDtJQUM5RCx5Q0FBaUIsR0FBakI7UUFDSSxJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUNqRCxDQUFDO0lBbERvQjtRQUFwQixnQkFBUyxDQUFDLFFBQVEsQ0FBQztrQ0FBZ0IsaUJBQVU7d0RBQUM7SUE2QjFCO1FBQXBCLGdCQUFTLENBQUMsUUFBUSxDQUFDO2tDQUFrQixnQ0FBc0I7MERBQUM7SUF6Q3BELGFBQWE7UUFMekIsZ0JBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxNQUFNO1lBQ2hCLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixXQUFXLEVBQUUsdUJBQXVCO1NBQ3ZDLENBQUM7O09BQ1csYUFBYSxDQStEekI7SUFBRCxvQkFBQztDQUFBLEFBL0RELElBK0RDO0FBL0RZLHNDQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIFZpZXdDaGlsZCxFbGVtZW50UmVmLCBBZnRlclZpZXdJbml0IH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IERyYXdlclRyYW5zaXRpb25CYXNlLCBTbGlkZUluT25Ub3BUcmFuc2l0aW9uIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1wcm8tdWkvc2lkZWRyYXdlclwiO1xuaW1wb3J0IHsgUmFkU2lkZURyYXdlckNvbXBvbmVudCB9IGZyb20gXCJuYXRpdmVzY3JpcHQtcHJvLXVpL3NpZGVkcmF3ZXIvYW5ndWxhclwiO1xuaW1wb3J0IGZyYW1lTW9kdWxlID0gcmVxdWlyZShcInRucy1jb3JlLW1vZHVsZXMvdWkvZnJhbWVcIik7XG5pbXBvcnQgeyBEaXJlY3Rpb25zIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1kaXJlY3Rpb25zXCI7XG5cbmltcG9ydCB7IFJhZGlhbE5lZWRsZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtcHJvLXVpL2dhdWdlc1wiO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogXCJGdWVsXCIsXG4gICAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcbiAgICB0ZW1wbGF0ZVVybDogXCIuL2Z1ZWwuY29tcG9uZW50Lmh0bWxcIlxufSlcbmV4cG9ydCBjbGFzcyBGdWVsQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbmZzdGF0aW9uPVwiXCI7XG5cbiAgIHByaXZhdGUgX25lZWRsZTogUmFkaWFsTmVlZGxlO1xuICAgIHB1YmxpYyB2YWx1ZXMgPSBbNjAsIDgwLCAxMjAsIDE2MF07XG5cbiAgICAvL2NvbnN0cnVjdG9yKCkgeyB9XG5cbiAgICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgICAgIHRoaXMuX25lZWRsZSA9IHRoaXMubmVlZGxlRWxlbWVudC5uYXRpdmVFbGVtZW50IGFzIFJhZGlhbE5lZWRsZTtcbiAgICB9XG5cbiAgICBAVmlld0NoaWxkKFwibmVlZGxlXCIpIG5lZWRsZUVsZW1lbnQ6IEVsZW1lbnRSZWY7XG5cbiAgICBwdWJsaWMgb25WYWx1ZUNoYW5nZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuX25lZWRsZS52YWx1ZSA9IHZhbHVlO1xuICAgIH1cblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLmRpcmVjdGlvbnMgPSBuZXcgRGlyZWN0aW9ucygpO1xuICB9XG4gICAgcHJpdmF0ZSBkaXJlY3Rpb25zOiBEaXJlY3Rpb25zO1xuICBkb0N1cnJlbnRMb2NhdGlvblRvQWRkcmVzcygpIHtcbiAgICB0aGlzLmRpcmVjdGlvbnMubmF2aWdhdGUoe1xuICAgICAgdG86IHtcbiAgICAgICAgYWRkcmVzczogdGhpcy5mc3RhdGlvblxuICAgICAgfVxuICAgIH0pLnRoZW4oKCkgPT4ge1xuICAgICAgY29uc29sZS5sb2coXCJDdXJyZW50IGxvY2F0aW9uIHRvIGFkZHJlc3MgZGlyZWN0aW9ucyBsYXVuY2hlZCFcIik7XG4gICAgfSwgKGVycikgPT4ge1xuICAgICAgYWxlcnQoZXJyKTtcbiAgICB9KTtcbiAgfVxuICBjb25zdXB0aW9uKCl7XG4gIGFsZXJ0KFwiZ2dnXCIpO1xuICB9XG5cbiAgICAvKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgICogVXNlIHRoZSBAVmlld0NoaWxkIGRlY29yYXRvciB0byBnZXQgYSByZWZlcmVuY2UgdG8gdGhlIGRyYXdlciBjb21wb25lbnQuXG4gICAgKiBJdCBpcyB1c2VkIGluIHRoZSBcIm9uRHJhd2VyQnV0dG9uVGFwXCIgZnVuY3Rpb24gYmVsb3cgdG8gbWFuaXB1bGF0ZSB0aGUgZHJhd2VyLlxuICAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gICAgQFZpZXdDaGlsZChcImRyYXdlclwiKSBkcmF3ZXJDb21wb25lbnQ6IFJhZFNpZGVEcmF3ZXJDb21wb25lbnQ7XG5cbiAgICBwcml2YXRlIF9zaWRlRHJhd2VyVHJhbnNpdGlvbjogRHJhd2VyVHJhbnNpdGlvbkJhc2U7XG5cbiAgICAvKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgICogVXNlIHRoZSBzaWRlRHJhd2VyVHJhbnNpdGlvbiBwcm9wZXJ0eSB0byBjaGFuZ2UgdGhlIG9wZW4vY2xvc2UgYW5pbWF0aW9uIG9mIHRoZSBkcmF3ZXIuXG4gICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5fc2lkZURyYXdlclRyYW5zaXRpb24gPSBuZXcgU2xpZGVJbk9uVG9wVHJhbnNpdGlvbigpO1xuICAgIH1cblxuICAgIGdldCBzaWRlRHJhd2VyVHJhbnNpdGlvbigpOiBEcmF3ZXJUcmFuc2l0aW9uQmFzZSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9zaWRlRHJhd2VyVHJhbnNpdGlvbjtcbiAgICB9XG5cbiAgICAvKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgICogQWNjb3JkaW5nIHRvIGd1aWRlbGluZXMsIGlmIHlvdSBoYXZlIGEgZHJhd2VyIG9uIHlvdXIgcGFnZSwgeW91IHNob3VsZCBhbHdheXNcbiAgICAqIGhhdmUgYSBidXR0b24gdGhhdCBvcGVucyBpdC4gVXNlIHRoZSBzaG93RHJhd2VyKCkgZnVuY3Rpb24gdG8gb3BlbiB0aGUgYXBwIGRyYXdlciBzZWN0aW9uLlxuICAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gICAgb25EcmF3ZXJCdXR0b25UYXAoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuZHJhd2VyQ29tcG9uZW50LnNpZGVEcmF3ZXIuc2hvd0RyYXdlcigpO1xuICAgIH1cbn0iXX0=