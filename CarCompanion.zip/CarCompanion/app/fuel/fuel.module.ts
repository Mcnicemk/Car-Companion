import { NgModule, NO_ERRORS_SCHEMA } from "@angular/core";
import { NativeScriptCommonModule } from "nativescript-angular/common";
import { NativeScriptUIGaugesModule } from "nativescript-pro-ui/gauges/angular";

import { SharedModule } from "../shared/shared.module";
import { FuelRoutingModule } from "./fuel-routing.module";
import { FuelComponent } from "./fuel.component";
import { NativeScriptFormsModule } from "nativescript-angular/forms";

@NgModule({
    imports: [
        NativeScriptCommonModule,
        FuelRoutingModule,
        SharedModule,
        NativeScriptUIGaugesModule,
         NativeScriptFormsModule
    ],
    declarations: [
        FuelComponent
    ],
    schemas: [
        NO_ERRORS_SCHEMA
    ]
})
export class FuelModule { }
