"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Rx_1 = require("rxjs/Rx");
require("rxjs/add/operator/map");
require("rxjs/add/operator/do");
var RestaurantsService = (function () {
    function RestaurantsService(http) {
        this.http = http;
        this.serverUrl = "https://maps.googleapis.com/maps/api/place/textsearch/json?";
    }
    RestaurantsService.prototype.GetPlaceData = function (lat, long, searchString) {
        return this.http.get(this.serverUrl + "query=" + searchString + "&location=" + lat + "," + long + "&radius= 10000&type=restaurant&key=AIzaSyCvP1FZQ1bsTpoqJGJKrP8vaoqwSMIz-Sg")
            .map(function (res) { return res.json(); })
            .catch(this.handleErrors);
    };
    RestaurantsService.prototype.handleErrors = function (error) {
        return Rx_1.Observable.throw(error);
    };
    RestaurantsService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [http_1.Http])
    ], RestaurantsService);
    return RestaurantsService;
}());
exports.RestaurantsService = RestaurantsService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzdGF1cmFudHNTZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicmVzdGF1cmFudHNTZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQXlDO0FBQ3pDLHNDQUFzRTtBQUN0RSw4QkFBbUM7QUFFbkMsaUNBQStCO0FBQy9CLGdDQUE4QjtBQUc5QjtJQUVDLDRCQUFvQixJQUFVO1FBQVYsU0FBSSxHQUFKLElBQUksQ0FBTTtRQUR0QixjQUFTLEdBQUcsNkRBQTZELENBQUE7SUFDakQsQ0FBQztJQUVqQyx5Q0FBWSxHQUFaLFVBQWEsR0FBRyxFQUFFLElBQUksRUFBRSxZQUFZO1FBQ3BDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsR0FBRyxZQUFZLEdBQUcsWUFBWSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxHQUFHLDRFQUE0RSxDQUFDO2FBQzlLLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBRSxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBRW5CO2FBQ0EsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBQ0QseUNBQVksR0FBWixVQUFhLEtBQWU7UUFDNUIsTUFBTSxDQUFDLGVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7SUFFL0IsQ0FBQztJQWRXLGtCQUFrQjtRQUQ5QixpQkFBVSxFQUFFO3lDQUdjLFdBQUk7T0FGbEIsa0JBQWtCLENBZTlCO0lBQUQseUJBQUM7Q0FBQSxBQWZELElBZUM7QUFmWSxnREFBa0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0luamVjdGFibGV9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7SHR0cCwgSGVhZGVycywgUmVzcG9uc2UsIFJlcXVlc3RPcHRpb25zfSBmcm9tIFwiQGFuZ3VsYXIvaHR0cFwiO1xyXG5pbXBvcnQge09ic2VydmFibGV9IGZyb20gXCJyeGpzL1J4XCI7XHJcbmltcG9ydCB7T2JzZXJ2YWJsZSBhcyBSeE9ic2VydmFibGV9IGZyb20gXCJyeGpzL09ic2VydmFibGVcIjtcclxuaW1wb3J0IFwicnhqcy9hZGQvb3BlcmF0b3IvbWFwXCI7XHJcbmltcG9ydCBcInJ4anMvYWRkL29wZXJhdG9yL2RvXCI7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBSZXN0YXVyYW50c1NlcnZpY2V7XHJcblx0cHJpdmF0ZSBzZXJ2ZXJVcmwgPSBcImh0dHBzOi8vbWFwcy5nb29nbGVhcGlzLmNvbS9tYXBzL2FwaS9wbGFjZS90ZXh0c2VhcmNoL2pzb24/XCJcclxuXHRjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHA6IEh0dHApe31cclxuXHJcblx0R2V0UGxhY2VEYXRhKGxhdCwgbG9uZywgc2VhcmNoU3RyaW5nKXtcclxuXHRyZXR1cm4gdGhpcy5odHRwLmdldCh0aGlzLnNlcnZlclVybCArIFwicXVlcnk9XCIgKyBzZWFyY2hTdHJpbmcgKyBcIiZsb2NhdGlvbj1cIiArIGxhdCArIFwiLFwiICsgbG9uZyArIFwiJnJhZGl1cz0gMTAwMDAmdHlwZT1yZXN0YXVyYW50JmtleT1BSXphU3lDdlAxRlpRMWJzVHBvcUpHSktyUDh2YW9xd1NNSXotU2dcIilcclxuXHQubWFwKHJlcz0+cmVzLmpzb24oKVxyXG5cclxuXHQpXHJcblx0LmNhdGNoKHRoaXMuaGFuZGxlRXJyb3JzKTtcclxuXHR9XHJcblx0aGFuZGxlRXJyb3JzKGVycm9yOiBSZXNwb25zZSl7XHJcblx0cmV0dXJuIE9ic2VydmFibGUudGhyb3coZXJyb3IpO1xyXG5cclxuXHR9XHJcbn0iXX0=