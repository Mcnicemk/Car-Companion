import {Injectable} from "@angular/core";
import {Http, Headers, Response, RequestOptions} from "@angular/http";
import {Observable} from "rxjs/Rx";
import {Observable as RxObservable} from "rxjs/Observable";
import "rxjs/add/operator/map";
import "rxjs/add/operator/do";

@Injectable()
export class RestaurantsService{
	private serverUrl = "https://maps.googleapis.com/maps/api/place/textsearch/json?"
	constructor(private http: Http){}

	GetPlaceData(lat, long, searchString){
	return this.http.get(this.serverUrl + "query=" + searchString + "&location=" + lat + "," + long + "&radius= 10000&type=restaurant&key=AIzaSyCvP1FZQ1bsTpoqJGJKrP8vaoqwSMIz-Sg")
	.map(res=>res.json()

	)
	.catch(this.handleErrors);
	}
	handleErrors(error: Response){
	return Observable.throw(error);

	}
}