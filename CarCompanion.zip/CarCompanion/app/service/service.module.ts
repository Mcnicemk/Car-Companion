import { NgModule, NO_ERRORS_SCHEMA } from "@angular/core";
import { NativeScriptCommonModule } from "nativescript-angular/common";

import { SharedModule } from "../shared/shared.module";
import { ServiceRoutingModule } from "./service-routing.module";
import { ServiceComponent } from "./service.component";
import { NativeScriptFormsModule } from "nativescript-angular/forms";

@NgModule({
    imports: [
        NativeScriptCommonModule,
        ServiceRoutingModule,
        SharedModule,
        NativeScriptFormsModule
    ],
    declarations: [
        ServiceComponent
    ],
    schemas: [
        NO_ERRORS_SCHEMA
    ]
})
export class ServiceModule { }
