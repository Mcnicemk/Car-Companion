"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var animations_1 = require("@angular/animations");
var sidedrawer_1 = require("nativescript-pro-ui/sidedrawer");
var angular_1 = require("nativescript-pro-ui/sidedrawer/angular");
var nativescript_directions_1 = require("nativescript-directions");
var nativescript_angular_1 = require("nativescript-angular");
var TripsComponent = (function () {
    function TripsComponent(modalService) {
        this.modalService = modalService;
        this.destination = "";
        this.directions = new nativescript_directions_1.Directions();
    }
    TripsComponent.prototype.CurrentLocationToAddress = function () {
        this.directions.navigate({
            to: {
                address: this.destination
            }
        }).then(function () {
            console.log("Current location to address directions launched!");
        }, function (err) {
            alert(err);
        });
    };
    /* ***********************************************************
    * Use the sideDrawerTransition property to change the open/close animation of the drawer.
    *************************************************************/
    TripsComponent.prototype.ngOnInit = function () {
        this._sideDrawerTransition = new sidedrawer_1.SlideInOnTopTransition();
    };
    Object.defineProperty(TripsComponent.prototype, "sideDrawerTransition", {
        get: function () {
            return this._sideDrawerTransition;
        },
        enumerable: true,
        configurable: true
    });
    /* ***********************************************************
    * According to guidelines, if you have a drawer on your page, you should always
    * have a button that opens it. Use the showDrawer() function to open the app drawer section.
    *************************************************************/
    TripsComponent.prototype.onDrawerButtonTap = function () {
        this.drawerComponent.sideDrawer.showDrawer();
    };
    //mapbox
    TripsComponent.prototype.onMapReady = function (args) {
        var _this = this;
        this.map = args.map;
        this.map.addMarkers([
            {
                id: 1,
                lat: 42.624189,
                lng: 23.372106,
                title: 'DevReach 2017',
                subtitle: 'Such an awesome little conference',
                onTap: function () {
                    console.log("DevReach 2017 was tapped");
                },
                onCalloutTap: function () {
                    console.log("DevReach 2017 callout tapped");
                }
            },
            // {
            //       id: 2,
            //       lat: 51.9280572,
            //       lng: 4.4201952,
            //       title: '{N} Developer day EU',
            //       subtitle: 'Tap to show directions (with waypoints)',
            //       icon: 'res://tnsmarker',
            //       onTap: () => {
            //         console.log("{N} Developer day EU was tapped");
            //       },
            //       onCalloutTap: () => {
            //         this.showDirectionsTo([
            //           {
            //             lat: 52.1851585,
            //             lng: 5.3974241
            //           },
            //           {
            //             lat: 51.9280572,
            //             lng: 4.4201952
            //           }
            //         ]);
            //       }
            //     },
            {
                id: 3,
                lat: 52.1851585,
                lng: 5.3974241,
                title: "Eddy's home",
                subtitle: "Tap to show directions (with waypoints)",
                iconPath: "images/mapmarkers/home_marker.png",
                onTap: function () {
                    console.log("Eddy's home was tapped");
                },
                onCalloutTap: function () {
                    _this.showDirectionsTo([
                        {
                            lat: 43.421834,
                            lng: 24.086096,
                        },
                        {
                            lat: 52.1851585,
                            lng: 5.3974241
                        }
                    ]);
                }
            },
            {
                id: 4,
                lat: 43.421834,
                lng: 24.086096,
                icon: 'res://truck1',
                title: "Dangerous truckdriver",
                subtitle: "Tap to show directions",
                onTap: function () {
                    console.log("Truck 1 was tapped");
                },
                onCalloutTap: function () {
                    _this.showDirectionsTo([{
                            lat: 43.421834,
                            lng: 24.086096,
                        }]);
                }
            },
            {
                id: 5,
                lat: 42.421834,
                lng: 26.786096,
                icon: 'res://truck2',
            },
            {
                id: 6,
                lat: 42.021834,
                lng: 25.086096,
                icon: 'res://truck3',
            }
        ]);
    };
    TripsComponent.prototype.showDirectionsTo = function (addresses) {
        this.directions.navigate({
            to: addresses,
            ios: {
                // Apple Maps can't show waypoints, so open Google maps if available in that case
                preferGoogleMaps: addresses.length > 1,
                allowGoogleMapsWeb: true
            }
        }).then(function () {
            console.log("Maps app launched.");
        }, function (error) {
            console.log(error);
        });
    };
    __decorate([
        core_1.ViewChild("drawer"),
        __metadata("design:type", angular_1.RadSideDrawerComponent)
    ], TripsComponent.prototype, "drawerComponent", void 0);
    TripsComponent = __decorate([
        core_1.Component({
            selector: "Trips",
            moduleId: module.id,
            templateUrl: "./trips.component.html",
            animations: [
                animations_1.trigger("flyInOut", [
                    animations_1.state("in", animations_1.style({ transform: "scale(1)", opacity: 1 })),
                    animations_1.transition("void => *", [
                        animations_1.style({ transform: "scale(0.9)", opacity: 0 }),
                        animations_1.animate("1000ms 100ms ease-out")
                    ])
                ]),
                animations_1.trigger("from-right", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1,
                        transform: "translate(0)"
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0,
                        transform: "translate(20%)"
                    })),
                    animations_1.transition("void => *", [animations_1.animate("600ms 1500ms ease-out")])
                ])
            ]
        }),
        __metadata("design:paramtypes", [nativescript_angular_1.ModalDialogService])
    ], TripsComponent);
    return TripsComponent;
}());
exports.TripsComponent = TripsComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHJpcHMuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidHJpcHMuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQThFO0FBQzlFLGtEQU02QjtBQUM3Qiw2REFBOEY7QUFDOUYsa0VBQWdGO0FBRWhGLG1FQUFxRTtBQUNyRSw2REFBMEQ7QUE0QjFEO0lBS0Usd0JBQXNCLFlBQWdDO1FBQWhDLGlCQUFZLEdBQVosWUFBWSxDQUFvQjtRQUp4RCxnQkFBVyxHQUFDLEVBQUUsQ0FBQztRQU1YLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxvQ0FBVSxFQUFFLENBQUM7SUFDckMsQ0FBQztJQUNELGlEQUF3QixHQUF4QjtRQUNFLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ3ZCLEVBQUUsRUFBRTtnQkFDRixPQUFPLEVBQUUsSUFBSSxDQUFDLFdBQVc7YUFDMUI7U0FDRixDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxrREFBa0QsQ0FBQyxDQUFDO1FBQ2xFLENBQUMsRUFBRSxVQUFDLEdBQUc7WUFDTCxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDYixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFTQzs7a0VBRThEO0lBQzlELGlDQUFRLEdBQVI7UUFDSSxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxtQ0FBc0IsRUFBRSxDQUFDO0lBQzlELENBQUM7SUFFRCxzQkFBSSxnREFBb0I7YUFBeEI7WUFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDO1FBQ3RDLENBQUM7OztPQUFBO0lBRUQ7OztrRUFHOEQ7SUFDOUQsMENBQWlCLEdBQWpCO1FBQ0ksSUFBSSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDakQsQ0FBQztJQUNELFFBQVE7SUFDUixtQ0FBVSxHQUFWLFVBQVcsSUFBSTtRQUFmLGlCQTZGRDtRQTVGQyxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7UUFDcEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7WUFDZDtnQkFDRSxFQUFFLEVBQUUsQ0FBQztnQkFDTCxHQUFHLEVBQUUsU0FBUztnQkFDZCxHQUFHLEVBQUUsU0FBUztnQkFDZCxLQUFLLEVBQUUsZUFBZTtnQkFDdEIsUUFBUSxFQUFFLG1DQUFtQztnQkFDN0MsS0FBSyxFQUFFO29CQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLENBQUMsQ0FBQztnQkFDMUMsQ0FBQztnQkFDRCxZQUFZLEVBQUU7b0JBQ1osT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO2dCQUM5QyxDQUFDO2FBQ0Y7WUFDRCxJQUFJO1lBQ0osZUFBZTtZQUNmLHlCQUF5QjtZQUN6Qix3QkFBd0I7WUFDeEIsdUNBQXVDO1lBQ3ZDLDZEQUE2RDtZQUM3RCxpQ0FBaUM7WUFDakMsdUJBQXVCO1lBQ3ZCLDBEQUEwRDtZQUMxRCxXQUFXO1lBQ1gsOEJBQThCO1lBQzlCLGtDQUFrQztZQUNsQyxjQUFjO1lBQ2QsK0JBQStCO1lBQy9CLDZCQUE2QjtZQUM3QixlQUFlO1lBQ2YsY0FBYztZQUNkLCtCQUErQjtZQUMvQiw2QkFBNkI7WUFDN0IsY0FBYztZQUNkLGNBQWM7WUFDZCxVQUFVO1lBQ1YsU0FBUztZQUNUO2dCQUNFLEVBQUUsRUFBRSxDQUFDO2dCQUNMLEdBQUcsRUFBRSxVQUFVO2dCQUNmLEdBQUcsRUFBRSxTQUFTO2dCQUNkLEtBQUssRUFBRSxhQUFhO2dCQUNwQixRQUFRLEVBQUUseUNBQXlDO2dCQUNuRCxRQUFRLEVBQUUsbUNBQW1DO2dCQUM3QyxLQUFLLEVBQUU7b0JBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO2dCQUN4QyxDQUFDO2dCQUNELFlBQVksRUFBRTtvQkFDWixLQUFJLENBQUMsZ0JBQWdCLENBQUM7d0JBQ3BCOzRCQUNFLEdBQUcsRUFBRSxTQUFTOzRCQUNkLEdBQUcsRUFBRSxTQUFTO3lCQUNmO3dCQUNEOzRCQUNFLEdBQUcsRUFBRSxVQUFVOzRCQUNmLEdBQUcsRUFBRSxTQUFTO3lCQUNmO3FCQUNGLENBQUMsQ0FBQztnQkFDTCxDQUFDO2FBQ0Y7WUFDRDtnQkFDRSxFQUFFLEVBQUUsQ0FBQztnQkFDTCxHQUFHLEVBQUUsU0FBUztnQkFDZCxHQUFHLEVBQUUsU0FBUztnQkFDZCxJQUFJLEVBQUUsY0FBYztnQkFDcEIsS0FBSyxFQUFFLHVCQUF1QjtnQkFDOUIsUUFBUSxFQUFFLHdCQUF3QjtnQkFDbEMsS0FBSyxFQUFFO29CQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztnQkFDcEMsQ0FBQztnQkFDRCxZQUFZLEVBQUU7b0JBQ1osS0FBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7NEJBQ3JCLEdBQUcsRUFBRSxTQUFTOzRCQUNkLEdBQUcsRUFBRSxTQUFTO3lCQUNmLENBQUMsQ0FBQyxDQUFDO2dCQUNOLENBQUM7YUFDRjtZQUNEO2dCQUNFLEVBQUUsRUFBRSxDQUFDO2dCQUNMLEdBQUcsRUFBRSxTQUFTO2dCQUNkLEdBQUcsRUFBRSxTQUFTO2dCQUNkLElBQUksRUFBRSxjQUFjO2FBQ3JCO1lBQ0Q7Z0JBQ0UsRUFBRSxFQUFFLENBQUM7Z0JBQ0wsR0FBRyxFQUFFLFNBQVM7Z0JBQ2QsR0FBRyxFQUFFLFNBQVM7Z0JBQ2QsSUFBSSxFQUFFLGNBQWM7YUFDckI7U0FDRixDQUNKLENBQUM7SUFDSixDQUFDO0lBRU8seUNBQWdCLEdBQXhCLFVBQXlCLFNBQWdDO1FBQ3ZELElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ3ZCLEVBQUUsRUFBRSxTQUFTO1lBQ2IsR0FBRyxFQUFFO2dCQUNILGlGQUFpRjtnQkFDakYsZ0JBQWdCLEVBQUUsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDO2dCQUN0QyxrQkFBa0IsRUFBRSxJQUFJO2FBQ3pCO1NBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUNwQyxDQUFDLEVBQUUsVUFBQSxLQUFLO1lBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFuSXNCO1FBQXBCLGdCQUFTLENBQUMsUUFBUSxDQUFDO2tDQUFrQixnQ0FBc0I7MkRBQUM7SUF4QnBELGNBQWM7UUExQjFCLGdCQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUsT0FBTztZQUNqQixRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsV0FBVyxFQUFFLHdCQUF3QjtZQUNyQyxVQUFVLEVBQUU7Z0JBQ1osb0JBQU8sQ0FBQyxVQUFVLEVBQUU7b0JBQ2xCLGtCQUFLLENBQUMsSUFBSSxFQUFFLGtCQUFLLENBQUMsRUFBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDO29CQUN2RCx1QkFBVSxDQUFDLFdBQVcsRUFBRTt3QkFDdEIsa0JBQUssQ0FBQyxFQUFDLFNBQVMsRUFBRSxZQUFZLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBQyxDQUFDO3dCQUM1QyxvQkFBTyxDQUFDLHVCQUF1QixDQUFDO3FCQUNqQyxDQUFDO2lCQUNILENBQUM7Z0JBQ0Ysb0JBQU8sQ0FBQyxZQUFZLEVBQUU7b0JBQ3BCLGtCQUFLLENBQUMsSUFBSSxFQUFFLGtCQUFLLENBQUM7d0JBQ2hCLFNBQVMsRUFBRSxDQUFDO3dCQUNaLFNBQVMsRUFBRSxjQUFjO3FCQUMxQixDQUFDLENBQUM7b0JBQ0gsa0JBQUssQ0FBQyxNQUFNLEVBQUUsa0JBQUssQ0FBQzt3QkFDbEIsU0FBUyxFQUFFLENBQUM7d0JBQ1osU0FBUyxFQUFFLGdCQUFnQjtxQkFDNUIsQ0FBQyxDQUFDO29CQUNILHVCQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsb0JBQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUM7aUJBQzVELENBQUM7YUFDSDtTQUVGLENBQUM7eUNBTW9DLHlDQUFrQjtPQUwzQyxjQUFjLENBNEoxQjtJQUFELHFCQUFDO0NBQUEsQUE1SkQsSUE0SkM7QUE1Slksd0NBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgVmlld0NoaWxkLFZpZXdDb250YWluZXJSZWYgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHtcbiAgdHJpZ2dlcixcbiAgc3RhdGUsXG4gIHN0eWxlLFxuICBhbmltYXRlLFxuICB0cmFuc2l0aW9uXG59IGZyb20gXCJAYW5ndWxhci9hbmltYXRpb25zXCI7XG5pbXBvcnQgeyBEcmF3ZXJUcmFuc2l0aW9uQmFzZSwgU2xpZGVJbk9uVG9wVHJhbnNpdGlvbiB9IGZyb20gXCJuYXRpdmVzY3JpcHQtcHJvLXVpL3NpZGVkcmF3ZXJcIjtcbmltcG9ydCB7IFJhZFNpZGVEcmF3ZXJDb21wb25lbnQgfSBmcm9tIFwibmF0aXZlc2NyaXB0LXByby11aS9zaWRlZHJhd2VyL2FuZ3VsYXJcIjtcbmltcG9ydCB7IE1hcGJveFZpZXdBcGksIFZpZXdwb3J0IGFzIE1hcGJveFZpZXdwb3J0IH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1tYXBib3hcIjtcbmltcG9ydCB7IEFkZHJlc3NPcHRpb25zLCBEaXJlY3Rpb25zIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1kaXJlY3Rpb25zXCI7XG5pbXBvcnQgeyBNb2RhbERpYWxvZ1NlcnZpY2UgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXJcIjtcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6IFwiVHJpcHNcIixcbiAgICBtb2R1bGVJZDogbW9kdWxlLmlkLFxuICAgIHRlbXBsYXRlVXJsOiBcIi4vdHJpcHMuY29tcG9uZW50Lmh0bWxcIixcbiAgICBhbmltYXRpb25zOiBbXG4gICAgdHJpZ2dlcihcImZseUluT3V0XCIsIFtcbiAgICAgIHN0YXRlKFwiaW5cIiwgc3R5bGUoe3RyYW5zZm9ybTogXCJzY2FsZSgxKVwiLCBvcGFjaXR5OiAxfSkpLFxuICAgICAgdHJhbnNpdGlvbihcInZvaWQgPT4gKlwiLCBbXG4gICAgICAgIHN0eWxlKHt0cmFuc2Zvcm06IFwic2NhbGUoMC45KVwiLCBvcGFjaXR5OiAwfSksXG4gICAgICAgIGFuaW1hdGUoXCIxMDAwbXMgMTAwbXMgZWFzZS1vdXRcIilcbiAgICAgIF0pXG4gICAgXSksXG4gICAgdHJpZ2dlcihcImZyb20tcmlnaHRcIiwgW1xuICAgICAgc3RhdGUoXCJpblwiLCBzdHlsZSh7XG4gICAgICAgIFwib3BhY2l0eVwiOiAxLFxuICAgICAgICB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKDApXCJcbiAgICAgIH0pKSxcbiAgICAgIHN0YXRlKFwidm9pZFwiLCBzdHlsZSh7XG4gICAgICAgIFwib3BhY2l0eVwiOiAwLFxuICAgICAgICB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKDIwJSlcIlxuICAgICAgfSkpLFxuICAgICAgdHJhbnNpdGlvbihcInZvaWQgPT4gKlwiLCBbYW5pbWF0ZShcIjYwMG1zIDE1MDBtcyBlYXNlLW91dFwiKV0pXG4gICAgXSlcbiAgXVxuXG59KVxuZXhwb3J0IGNsYXNzIFRyaXBzQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbmRlc3RpbmF0aW9uPVwiXCI7XG4gICBwcml2YXRlIGRpcmVjdGlvbnM6IERpcmVjdGlvbnM7XG4gICBwcml2YXRlIG1hcDogTWFwYm94Vmlld0FwaTtcblxuICBjb25zdHJ1Y3Rvcihwcm90ZWN0ZWQgbW9kYWxTZXJ2aWNlOiBNb2RhbERpYWxvZ1NlcnZpY2UpIHtcbiAgIFxuICAgIHRoaXMuZGlyZWN0aW9ucyA9IG5ldyBEaXJlY3Rpb25zKCk7XG4gIH1cbiAgQ3VycmVudExvY2F0aW9uVG9BZGRyZXNzKCkge1xuICAgIHRoaXMuZGlyZWN0aW9ucy5uYXZpZ2F0ZSh7XG4gICAgICB0bzoge1xuICAgICAgICBhZGRyZXNzOiB0aGlzLmRlc3RpbmF0aW9uXG4gICAgICB9XG4gICAgfSkudGhlbigoKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhcIkN1cnJlbnQgbG9jYXRpb24gdG8gYWRkcmVzcyBkaXJlY3Rpb25zIGxhdW5jaGVkIVwiKTtcbiAgICB9LCAoZXJyKSA9PiB7XG4gICAgICBhbGVydChlcnIpO1xuICAgIH0pO1xuICB9XG4gICAgLyogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICAqIFVzZSB0aGUgQFZpZXdDaGlsZCBkZWNvcmF0b3IgdG8gZ2V0IGEgcmVmZXJlbmNlIHRvIHRoZSBkcmF3ZXIgY29tcG9uZW50LlxuICAgICogSXQgaXMgdXNlZCBpbiB0aGUgXCJvbkRyYXdlckJ1dHRvblRhcFwiIGZ1bmN0aW9uIGJlbG93IHRvIG1hbmlwdWxhdGUgdGhlIGRyYXdlci5cbiAgICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICAgIEBWaWV3Q2hpbGQoXCJkcmF3ZXJcIikgZHJhd2VyQ29tcG9uZW50OiBSYWRTaWRlRHJhd2VyQ29tcG9uZW50O1xuXG4gICAgcHJpdmF0ZSBfc2lkZURyYXdlclRyYW5zaXRpb246IERyYXdlclRyYW5zaXRpb25CYXNlO1xuXG4gICAgLyogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICAqIFVzZSB0aGUgc2lkZURyYXdlclRyYW5zaXRpb24gcHJvcGVydHkgdG8gY2hhbmdlIHRoZSBvcGVuL2Nsb3NlIGFuaW1hdGlvbiBvZiB0aGUgZHJhd2VyLlxuICAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuX3NpZGVEcmF3ZXJUcmFuc2l0aW9uID0gbmV3IFNsaWRlSW5PblRvcFRyYW5zaXRpb24oKTtcbiAgICB9XG5cbiAgICBnZXQgc2lkZURyYXdlclRyYW5zaXRpb24oKTogRHJhd2VyVHJhbnNpdGlvbkJhc2Uge1xuICAgICAgICByZXR1cm4gdGhpcy5fc2lkZURyYXdlclRyYW5zaXRpb247XG4gICAgfVxuXG4gICAgLyogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICAqIEFjY29yZGluZyB0byBndWlkZWxpbmVzLCBpZiB5b3UgaGF2ZSBhIGRyYXdlciBvbiB5b3VyIHBhZ2UsIHlvdSBzaG91bGQgYWx3YXlzXG4gICAgKiBoYXZlIGEgYnV0dG9uIHRoYXQgb3BlbnMgaXQuIFVzZSB0aGUgc2hvd0RyYXdlcigpIGZ1bmN0aW9uIHRvIG9wZW4gdGhlIGFwcCBkcmF3ZXIgc2VjdGlvbi5cbiAgICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICAgIG9uRHJhd2VyQnV0dG9uVGFwKCk6IHZvaWQge1xuICAgICAgICB0aGlzLmRyYXdlckNvbXBvbmVudC5zaWRlRHJhd2VyLnNob3dEcmF3ZXIoKTtcbiAgICB9XG4gICAgLy9tYXBib3hcbiAgICBvbk1hcFJlYWR5KGFyZ3MpOiB2b2lkIHtcbiAgICB0aGlzLm1hcCA9IGFyZ3MubWFwO1xuICAgIHRoaXMubWFwLmFkZE1hcmtlcnMoW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAxLFxuICAgICAgICAgICAgbGF0OiA0Mi42MjQxODksXG4gICAgICAgICAgICBsbmc6IDIzLjM3MjEwNixcbiAgICAgICAgICAgIHRpdGxlOiAnRGV2UmVhY2ggMjAxNycsXG4gICAgICAgICAgICBzdWJ0aXRsZTogJ1N1Y2ggYW4gYXdlc29tZSBsaXR0bGUgY29uZmVyZW5jZScsXG4gICAgICAgICAgICBvblRhcDogKCkgPT4ge1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkRldlJlYWNoIDIwMTcgd2FzIHRhcHBlZFwiKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvbkNhbGxvdXRUYXA6ICgpID0+IHtcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJEZXZSZWFjaCAyMDE3IGNhbGxvdXQgdGFwcGVkXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAgLy8ge1xuICAgICAgICAgIC8vICAgICAgIGlkOiAyLFxuICAgICAgICAgIC8vICAgICAgIGxhdDogNTEuOTI4MDU3MixcbiAgICAgICAgICAvLyAgICAgICBsbmc6IDQuNDIwMTk1MixcbiAgICAgICAgICAvLyAgICAgICB0aXRsZTogJ3tOfSBEZXZlbG9wZXIgZGF5IEVVJyxcbiAgICAgICAgICAvLyAgICAgICBzdWJ0aXRsZTogJ1RhcCB0byBzaG93IGRpcmVjdGlvbnMgKHdpdGggd2F5cG9pbnRzKScsXG4gICAgICAgICAgLy8gICAgICAgaWNvbjogJ3JlczovL3Ruc21hcmtlcicsXG4gICAgICAgICAgLy8gICAgICAgb25UYXA6ICgpID0+IHtcbiAgICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKFwie059IERldmVsb3BlciBkYXkgRVUgd2FzIHRhcHBlZFwiKTtcbiAgICAgICAgICAvLyAgICAgICB9LFxuICAgICAgICAgIC8vICAgICAgIG9uQ2FsbG91dFRhcDogKCkgPT4ge1xuICAgICAgICAgIC8vICAgICAgICAgdGhpcy5zaG93RGlyZWN0aW9uc1RvKFtcbiAgICAgICAgICAvLyAgICAgICAgICAge1xuICAgICAgICAgIC8vICAgICAgICAgICAgIGxhdDogNTIuMTg1MTU4NSxcbiAgICAgICAgICAvLyAgICAgICAgICAgICBsbmc6IDUuMzk3NDI0MVxuICAgICAgICAgIC8vICAgICAgICAgICB9LFxuICAgICAgICAgIC8vICAgICAgICAgICB7XG4gICAgICAgICAgLy8gICAgICAgICAgICAgbGF0OiA1MS45MjgwNTcyLFxuICAgICAgICAgIC8vICAgICAgICAgICAgIGxuZzogNC40MjAxOTUyXG4gICAgICAgICAgLy8gICAgICAgICAgIH1cbiAgICAgICAgICAvLyAgICAgICAgIF0pO1xuICAgICAgICAgIC8vICAgICAgIH1cbiAgICAgICAgICAvLyAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogMyxcbiAgICAgICAgICAgIGxhdDogNTIuMTg1MTU4NSxcbiAgICAgICAgICAgIGxuZzogNS4zOTc0MjQxLFxuICAgICAgICAgICAgdGl0bGU6IFwiRWRkeSdzIGhvbWVcIixcbiAgICAgICAgICAgIHN1YnRpdGxlOiBcIlRhcCB0byBzaG93IGRpcmVjdGlvbnMgKHdpdGggd2F5cG9pbnRzKVwiLFxuICAgICAgICAgICAgaWNvblBhdGg6IFwiaW1hZ2VzL21hcG1hcmtlcnMvaG9tZV9tYXJrZXIucG5nXCIsXG4gICAgICAgICAgICBvblRhcDogKCkgPT4ge1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkVkZHkncyBob21lIHdhcyB0YXBwZWRcIik7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgb25DYWxsb3V0VGFwOiAoKSA9PiB7XG4gICAgICAgICAgICAgIHRoaXMuc2hvd0RpcmVjdGlvbnNUbyhbXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbGF0OiA0My40MjE4MzQsXG4gICAgICAgICAgICAgICAgICBsbmc6IDI0LjA4NjA5NixcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIGxhdDogNTIuMTg1MTU4NSxcbiAgICAgICAgICAgICAgICAgIGxuZzogNS4zOTc0MjQxXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiA0LFxuICAgICAgICAgICAgbGF0OiA0My40MjE4MzQsXG4gICAgICAgICAgICBsbmc6IDI0LjA4NjA5NixcbiAgICAgICAgICAgIGljb246ICdyZXM6Ly90cnVjazEnLFxuICAgICAgICAgICAgdGl0bGU6IFwiRGFuZ2Vyb3VzIHRydWNrZHJpdmVyXCIsXG4gICAgICAgICAgICBzdWJ0aXRsZTogXCJUYXAgdG8gc2hvdyBkaXJlY3Rpb25zXCIsXG4gICAgICAgICAgICBvblRhcDogKCkgPT4ge1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlRydWNrIDEgd2FzIHRhcHBlZFwiKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvbkNhbGxvdXRUYXA6ICgpID0+IHtcbiAgICAgICAgICAgICAgdGhpcy5zaG93RGlyZWN0aW9uc1RvKFt7XG4gICAgICAgICAgICAgICAgbGF0OiA0My40MjE4MzQsXG4gICAgICAgICAgICAgICAgbG5nOiAyNC4wODYwOTYsXG4gICAgICAgICAgICAgIH1dKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiA1LFxuICAgICAgICAgICAgbGF0OiA0Mi40MjE4MzQsXG4gICAgICAgICAgICBsbmc6IDI2Ljc4NjA5NixcbiAgICAgICAgICAgIGljb246ICdyZXM6Ly90cnVjazInLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6IDYsXG4gICAgICAgICAgICBsYXQ6IDQyLjAyMTgzNCxcbiAgICAgICAgICAgIGxuZzogMjUuMDg2MDk2LFxuICAgICAgICAgICAgaWNvbjogJ3JlczovL3RydWNrMycsXG4gICAgICAgICAgfVxuICAgICAgICBdXG4gICAgKTtcbiAgfVxuXG4gIHByaXZhdGUgc2hvd0RpcmVjdGlvbnNUbyhhZGRyZXNzZXM6IEFycmF5PEFkZHJlc3NPcHRpb25zPik6IHZvaWQge1xuICAgIHRoaXMuZGlyZWN0aW9ucy5uYXZpZ2F0ZSh7XG4gICAgICB0bzogYWRkcmVzc2VzLFxuICAgICAgaW9zOiB7XG4gICAgICAgIC8vIEFwcGxlIE1hcHMgY2FuJ3Qgc2hvdyB3YXlwb2ludHMsIHNvIG9wZW4gR29vZ2xlIG1hcHMgaWYgYXZhaWxhYmxlIGluIHRoYXQgY2FzZVxuICAgICAgICBwcmVmZXJHb29nbGVNYXBzOiBhZGRyZXNzZXMubGVuZ3RoID4gMSxcbiAgICAgICAgYWxsb3dHb29nbGVNYXBzV2ViOiB0cnVlXG4gICAgICB9XG4gICAgfSkudGhlbigoKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhcIk1hcHMgYXBwIGxhdW5jaGVkLlwiKTtcbiAgICB9LCBlcnJvciA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhlcnJvcik7XG4gICAgfSk7XG4gIH1cbn1cbiJdfQ==