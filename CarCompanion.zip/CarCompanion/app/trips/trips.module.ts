import { NgModule, NO_ERRORS_SCHEMA } from "@angular/core";
import { NativeScriptCommonModule } from "nativescript-angular/common";

import { SharedModule } from "../shared/shared.module";
import { TripsRoutingModule } from "./trips-routing.module";
import { TripsComponent } from "./trips.component";
import { NativeScriptFormsModule } from "nativescript-angular/forms";
import { registerElement } from "nativescript-angular/element-registry";
registerElement("Mapbox", () => require("nativescript-mapbox").MapboxView);

@NgModule({
    imports: [
        NativeScriptCommonModule,
        TripsRoutingModule,
        SharedModule,
         NativeScriptFormsModule
    ],
    declarations: [
        TripsComponent
    ],
    schemas: [
        NO_ERRORS_SCHEMA
    ]
})
export class TripsModule { }
