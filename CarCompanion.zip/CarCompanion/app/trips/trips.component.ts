import { Component, OnInit, ViewChild,ViewContainerRef } from "@angular/core";
import {
  trigger,
  state,
  style,
  animate,
  transition
} from "@angular/animations";
import { DrawerTransitionBase, SlideInOnTopTransition } from "nativescript-pro-ui/sidedrawer";
import { RadSideDrawerComponent } from "nativescript-pro-ui/sidedrawer/angular";
import { MapboxViewApi, Viewport as MapboxViewport } from "nativescript-mapbox";
import { AddressOptions, Directions } from "nativescript-directions";
import { ModalDialogService } from "nativescript-angular";

@Component({
    selector: "Trips",
    moduleId: module.id,
    templateUrl: "./trips.component.html",
    animations: [
    trigger("flyInOut", [
      state("in", style({transform: "scale(1)", opacity: 1})),
      transition("void => *", [
        style({transform: "scale(0.9)", opacity: 0}),
        animate("1000ms 100ms ease-out")
      ])
    ]),
    trigger("from-right", [
      state("in", style({
        "opacity": 1,
        transform: "translate(0)"
      })),
      state("void", style({
        "opacity": 0,
        transform: "translate(20%)"
      })),
      transition("void => *", [animate("600ms 1500ms ease-out")])
    ])
  ]

})
export class TripsComponent implements OnInit {
destination="";
   private directions: Directions;
   private map: MapboxViewApi;

  constructor(protected modalService: ModalDialogService) {
   
    this.directions = new Directions();
  }
  CurrentLocationToAddress() {
    this.directions.navigate({
      to: {
        address: this.destination
      }
    }).then(() => {
      console.log("Current location to address directions launched!");
    }, (err) => {
      alert(err);
    });
  }
    /* ***********************************************************
    * Use the @ViewChild decorator to get a reference to the drawer component.
    * It is used in the "onDrawerButtonTap" function below to manipulate the drawer.
    *************************************************************/
    @ViewChild("drawer") drawerComponent: RadSideDrawerComponent;

    private _sideDrawerTransition: DrawerTransitionBase;

    /* ***********************************************************
    * Use the sideDrawerTransition property to change the open/close animation of the drawer.
    *************************************************************/
    ngOnInit(): void {
        this._sideDrawerTransition = new SlideInOnTopTransition();
    }

    get sideDrawerTransition(): DrawerTransitionBase {
        return this._sideDrawerTransition;
    }

    /* ***********************************************************
    * According to guidelines, if you have a drawer on your page, you should always
    * have a button that opens it. Use the showDrawer() function to open the app drawer section.
    *************************************************************/
    onDrawerButtonTap(): void {
        this.drawerComponent.sideDrawer.showDrawer();
    }
    //mapbox
    onMapReady(args): void {
    this.map = args.map;
    this.map.addMarkers([
          {
            id: 1,
            lat: 42.624189,
            lng: 23.372106,
            title: 'DevReach 2017',
            subtitle: 'Such an awesome little conference',
            onTap: () => {
              console.log("DevReach 2017 was tapped");
            },
            onCalloutTap: () => {
              console.log("DevReach 2017 callout tapped");
            }
          },
          // {
          //       id: 2,
          //       lat: 51.9280572,
          //       lng: 4.4201952,
          //       title: '{N} Developer day EU',
          //       subtitle: 'Tap to show directions (with waypoints)',
          //       icon: 'res://tnsmarker',
          //       onTap: () => {
          //         console.log("{N} Developer day EU was tapped");
          //       },
          //       onCalloutTap: () => {
          //         this.showDirectionsTo([
          //           {
          //             lat: 52.1851585,
          //             lng: 5.3974241
          //           },
          //           {
          //             lat: 51.9280572,
          //             lng: 4.4201952
          //           }
          //         ]);
          //       }
          //     },
          {
            id: 3,
            lat: 52.1851585,
            lng: 5.3974241,
            title: "Eddy's home",
            subtitle: "Tap to show directions (with waypoints)",
            iconPath: "images/mapmarkers/home_marker.png",
            onTap: () => {
              console.log("Eddy's home was tapped");
            },
            onCalloutTap: () => {
              this.showDirectionsTo([
                {
                  lat: 43.421834,
                  lng: 24.086096,
                },
                {
                  lat: 52.1851585,
                  lng: 5.3974241
                }
              ]);
            }
          },
          {
            id: 4,
            lat: 43.421834,
            lng: 24.086096,
            icon: 'res://truck1',
            title: "Dangerous truckdriver",
            subtitle: "Tap to show directions",
            onTap: () => {
              console.log("Truck 1 was tapped");
            },
            onCalloutTap: () => {
              this.showDirectionsTo([{
                lat: 43.421834,
                lng: 24.086096,
              }]);
            }
          },
          {
            id: 5,
            lat: 42.421834,
            lng: 26.786096,
            icon: 'res://truck2',
          },
          {
            id: 6,
            lat: 42.021834,
            lng: 25.086096,
            icon: 'res://truck3',
          }
        ]
    );
  }

  private showDirectionsTo(addresses: Array<AddressOptions>): void {
    this.directions.navigate({
      to: addresses,
      ios: {
        // Apple Maps can't show waypoints, so open Google maps if available in that case
        preferGoogleMaps: addresses.length > 1,
        allowGoogleMapsWeb: true
      }
    }).then(() => {
      console.log("Maps app launched.");
    }, error => {
      console.log(error);
    });
  }
}
